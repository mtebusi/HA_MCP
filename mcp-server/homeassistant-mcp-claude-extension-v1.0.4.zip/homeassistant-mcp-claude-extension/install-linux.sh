#!/bin/bash
CONFIG_DIR="$HOME/.config/Claude"
mkdir -p "$CONFIG_DIR"
cp config.json "$CONFIG_DIR/claude_desktop_config.json"
echo "Configuration installed to: $CONFIG_DIR/claude_desktop_config.json"
echo "Please restart Claude Desktop"
